<?php
  print('FAST REPORT');
?>
