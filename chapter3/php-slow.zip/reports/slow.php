<?php
  sleep(600);
  print('SLOW REPORT');
?>
